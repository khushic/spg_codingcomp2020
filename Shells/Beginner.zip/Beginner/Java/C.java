import java.util.Scanner;

public class C {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(wakeUp(Boolean.parseBoolean(in[0]), Boolean.parseBoolean(in[1])));
	}
   public static String wakeUp(boolean winter, boolean vacation){
		//TYPE CODE HERE
		return "";
   }
}