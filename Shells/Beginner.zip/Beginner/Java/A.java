import java.util.Scanner;

public class A {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(printBackwards(str));
	}
	public static String printBackwards(String str){
		//TYPE CODE HERE
		return "";
   }
}