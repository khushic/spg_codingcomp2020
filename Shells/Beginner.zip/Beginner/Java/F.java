import java.util.Scanner;

public class F {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(addFrac(Integer.parseInt(in[0]), Integer.parseInt(in[1]), Integer.parseInt(in[2]), Integer.parseInt(in[3])));
	}
	   public static String addFrac(int num1, int denom1, int num2, int denom2){
		//TYPE CODE HERE
		return "";
   }
}