import java.util.Scanner;

public class G {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(shareCookies(Integer.parseInt(str)));
	}
	   public static String shareCookies(int cookies){
		//TYPE CODE HERE
		return "";
   }
}