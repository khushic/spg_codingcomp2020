import java.util.Scanner;

public class I {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(uppercase(str));
	}
	   public static String uppercase(String str){
		//TYPE CODE HERE
		return "";
   }
}