import java.util.Scanner;

public class E {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(calculator(Double.parseDouble(in[0]), Double.parseDouble(in[1]), in[2]));
	}
	public static double calculator(double a, double b, String operation){
		//TYPE CODE HERE
		return 0.0;
	}
}