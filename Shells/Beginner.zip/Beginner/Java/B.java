import java.util.Scanner;

public class B {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(partOfString(in[0], Integer.parseInt(in[1]), Integer.parseInt(in[2])));
	}
	public static String partOfString(String str, int start, int end){
		//TYPE CODE HERE
		return "";
	}
}