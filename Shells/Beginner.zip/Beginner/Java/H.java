import java.util.Scanner;

public class H {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(longerWord(in[0], in[1]));
	}
	public static String longerWord(String str1, String str2){  
		//TYPE CODE HERE
		return "";
	}
}