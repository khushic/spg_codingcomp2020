import java.util.Scanner;

public class J {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(spaces(str));
	}
	   public static String spaces(String str){
		//TYPE CODE HERE
		return "";
   }
}