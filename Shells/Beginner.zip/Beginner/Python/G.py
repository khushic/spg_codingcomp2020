def shareCookies(c):
    #TYPE CODE HERE
    return ""

cookies = int(input())
print(shareCookies(cookies))
