def uppercase(s1):
    #TYPE CODE HERE
    return ""

string1 = input()
print(uppercase(string1))
