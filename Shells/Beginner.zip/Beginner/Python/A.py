def reverse(str):
    #TYPE CODE HERE
    return ""

print(reverse(input()))
