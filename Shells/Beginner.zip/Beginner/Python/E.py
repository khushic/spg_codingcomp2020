def mathOperation(a,b,operation):
    #TYPE CODE HERE
    return -1

num1 = float(input())
num2 = float(input())
math = input()
print(mathOperation(num1,num2,math))
