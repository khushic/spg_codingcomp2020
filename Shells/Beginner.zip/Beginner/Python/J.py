def spaces(s1):
    #TYPE CODE HERE
    return ""

string1 = input()
print(spaces(string1))