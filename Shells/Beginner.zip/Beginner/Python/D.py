def swap(string, a, b):
    #TYPE STRING HERE
    return ""


string = input()
index1 = int(input())
index2 = int(input())
print(swap(string, index1, index2))
