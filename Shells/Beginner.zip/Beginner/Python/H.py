def longerString(s1,s2):
    #TYPE CODE HERE
    return ""

string1 = input()
string2 = input()
print(longerString(string1,string2))
