def addFrac(n1,d1,n2,d2):
    #TYPE CODE HERE
    return ""

num1 = int(input())
denom1= int(input())
num2 = int(input())
denom2 = int(input())
print(addFrac(num1,denom1,num2,denom2))