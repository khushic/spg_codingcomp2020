def booleans(a,b):
    #TYPE CODE HERE
    return ""

isWinter = (input())
isBreak = (input())
print(booleans(isWinter,isBreak))