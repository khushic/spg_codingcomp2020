def repeatedlength(n):
    #TYPE CODE HERE
    return -1

n = input()

print(repeatedlength(n))