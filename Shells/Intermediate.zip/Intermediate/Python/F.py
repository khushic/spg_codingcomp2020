def substring(full, sub):
    #TYPE CODE HERE
    return -1

n = input().split(", ")
full = n[0]
sub = n[1]
print(substring(full, sub))