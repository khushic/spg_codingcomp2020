def fibonacci(n):
    #TYPE CODE HERE
    return -1

n = int(input())
print(fibonacci(n))