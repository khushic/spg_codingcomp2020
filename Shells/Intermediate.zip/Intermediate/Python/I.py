def mode(n):
    #TYPE CODE HERE
    return -1

n = input().split(", ")
print(mode(n))