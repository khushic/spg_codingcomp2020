def sort(n):
    #TYPE CODE HERE
    return ""

n = input()
n_list = n.split(", ")
n_ints = []
for i in n_list:
    n_ints.append(int(i))

print(sort(n_ints))