def prime(n):
    #TYPE CODE HERE
    return True

n = int(input())
print(prime(n))