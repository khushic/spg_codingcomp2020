def stringpyramid(n):
    #TYPE CODE HERE
    #NOTE, UNLIKE THE OTHER SHELL FILES YOU HAVE TO PRINT INSTEAD OF RETURNING
    print()

n = input()
stringpyramid(n)