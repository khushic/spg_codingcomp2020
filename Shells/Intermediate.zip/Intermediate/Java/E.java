import java.util.Scanner;

public class E {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(isPrime(Integer.parseInt(str)));
	}
	public static boolean isPrime(int n) {
		//TYPE CODE HERE
		return true;
   }
}