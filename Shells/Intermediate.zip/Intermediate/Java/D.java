import java.util.Scanner;

public class D {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		wordScrambler(str);
	}
	public static void wordScrambler(String str){
		//TYPE CODE HERE
		System.out.println("");
   }
}