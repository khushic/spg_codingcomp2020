import java.util.Scanner;

public class F {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(", ");
		System.out.println(substringInString(in[0], in[1]));
	}
	public static int substringInString(String str, String findStr) {
		//TYPE CODE HERE
		return -1;
	}
}