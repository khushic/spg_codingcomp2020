import java.util.Scanner;

public class C {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(average(Integer.parseInt(str)));
	}
	public static int average(int n){
		//TYPE CODE HERE
		return -1;
   }
}